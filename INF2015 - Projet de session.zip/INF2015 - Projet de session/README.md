Equipe19
========
L'application développée est un logiciel qui effectue la validation du
temps travaillé par des employés dans le respect des règles de l'entreprise.
