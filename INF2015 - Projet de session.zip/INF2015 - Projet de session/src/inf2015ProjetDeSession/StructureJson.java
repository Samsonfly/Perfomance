package inf2015ProjetDeSession;

import java.io.FileWriter;
import java.io.IOException;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

/**
 * @author Equipe 19
 */

public class StructureJson
{
    protected String[] args;
    protected JSONArray resultat;
    
    public StructureJson( String[] args )
    {
        this.args = args;
        this.resultat = new JSONArray();
    }
    
    public void verifierContraintes() throws IOException 
    {
        verifierExtensionsFichiers();
        verifierCongesFinSemaine();
        verifierStructureNumeroEmploye();
        verifierActivitesParJour();
        verifierActivitesZeroMinute();
        verifierCongeParentalSemaine();
        verifierActivitesParallele();
        verifierNombreMinutes();
        verifierAccesTempsTransportEmploye();
    }

    public void verifierNombreArguments ()
    { 
        if(args.length < 2)
        {
            System.err.println("Vous devez passer les noms des deux paramètres (fichier d'entre et fichier de sortie) en argument");
            System.exit(1);
        }
    }

    public void verifierExtensionsFichiers()
    {
        verifierNombreArguments();
        
        for (int i=0; i<args.length; ++i)
        {
            String extensionFichier = args[i].substring(args[i].lastIndexOf(".")+1);
            
            if ( !extensionFichier.equals("json") )
            {
                System.err.println("Les fichies d'entree et sortie doivent etre du format JSON");
                System.exit(1);
            }
        }    
    }

    public void verifierStructureNumeroEmploye() throws IOException
    {
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();

        if (feuilleDeTempsHebdomadaire.getString("numero_employe").equals(""))
        {
            System.err.println("Aucun numero d'employe trouve dans le fichier d'entree.");
            System.exit(0);
        }
    }

    public void verifierCongesFinSemaine () throws IOException
    {
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};            
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();
        
        for (int i=0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));

            if ( jours[i].equals("weekend1") || jours[i].equals("weekend2") )
            {
                for (int j=0; j < feuilleDeTempsJournalier.size(); ++j)
                {
                    JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                    if ( projetCourant.getInt("projet") == 996 )
                    {
                        resultat.add("Il n'est pas permis d'utliser le conge parentale la fin de semaine.");
                    }else if ( projetCourant.getInt("projet") == 997 )
                    {
                        resultat.add("Il n'est pas permis d'utliser la journee de vacance la fin de semaine.");
                        
                    }else if ( projetCourant.getInt("projet") == 998)
                    {
                        resultat.add("Il n'est pas permis d'utliser le conge ferie la fin de semaine.");
                        
                    }else if (projetCourant.getInt("projet") == 999)
                    {
                        resultat.add("Il n'est pas permis d'utliser le conge maladie la fin de semaine.");                        
                    }
                }
            }
        }
    }

    public void verifierActivitesParJour() throws IOException
    {
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};            
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();
        
        for (int i=0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));

            if ( feuilleDeTempsJournalier.size() > 1 )
            {
                for (int j=0; j < feuilleDeTempsJournalier.size()-1; ++j)
                {
                    JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);                    
                    for(int k=j+1; k < feuilleDeTempsJournalier.size(); ++k)
                    {
                        if ( projetCourant.getInt("projet") ==  feuilleDeTempsJournalier.getJSONObject(k).getInt("projet"))
                        {
                            
                            resultat.add( "Le " +jours[i] + " contient deux activités avec le même code de projet.");
                        }
                    }
                }
            }
        }
    }

    public void verifierActivitesZeroMinute() throws IOException
    {
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};            
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();
        
        for (int i=0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));

                for (int j=0; j < feuilleDeTempsJournalier.size(); ++j)
                {
                    JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                    if ( projetCourant.getInt("minutes") == 0 )
                    {
                        resultat.add(jours[i] + " contient une activité avec 0 minute.");
                    }
                }
        }
    }

    public void verifierCongeParentalSemaine() throws IOException
    {
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};            
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();
        int nombreCongeParental = 0;
        
        for (int i=0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));

                for (int j=0; j < feuilleDeTempsJournalier.size(); ++j)
                {
                    JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                    if ( projetCourant.getInt("projet") == 996 )
                    {
                        nombreCongeParental++;
                    }
                }            
        }
        if(nombreCongeParental > 1)
        {
            resultat.add("Il n'est pas permis d'utiliser plus d'un congé parental dans la semaine.");
        }
    }

    public void verifierActivitesParallele() throws IOException
    {
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};            
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();
        
        for (int i=0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));

            if ( feuilleDeTempsJournalier.size() > 1 )
            {
                for (int j=0; j < feuilleDeTempsJournalier.size(); ++j)
                {
                    JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);                    
                    
                    if ( projetCourant.getInt("projet") == 996 )
                    {
                        resultat.add("Il n'est pas permis d'avoir d'autre actives lorsque en conge parental");
                    }else if ( projetCourant.getInt("projet") == 999 )
                    {
                        resultat.add("Il n'est pas permis d'avoir d'autre actives lorsque en conge maladie");
                    }
                }
            }
        }
    }

    public void verifierNombreMinutes() throws IOException
    {
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};            
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();
        
        for (int i=0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));

                for (int j=0; j < feuilleDeTempsJournalier.size(); ++j)
                {
                    JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);                    
                    
                    if ( (projetCourant.getInt("projet") == 996) && (projetCourant.getInt("minutes") != 480) )
                    {
                        resultat.add("Le " + jours[i] + " contient une journée de conge parental n'ayant pas 480 minutes.");
                    }else if ( (projetCourant.getInt("projet") == 997) && (projetCourant.getInt("minutes") != 480) )
                    {
                        resultat.add("Le " + jours[i] + " contient une journée de vacances n'ayant pas 480 minutes.");
                    }else if ( (projetCourant.getInt("projet") == 998) && (projetCourant.getInt("minutes") != 480) )
                    {
                        resultat.add("Le " + jours[i] + " contient une journée de conge ferie n'ayant pas 480 minutes.");
                    }else if ( (projetCourant.getInt("projet") == 999) && (projetCourant.getInt("minutes") != 480) )
                    {
                        resultat.add("Le " + jours[i] + " contient une journée de conge maladie n'ayant pas 480 minutes.");
                    }
                }
        }
    }

    public void verifierAccesTempsTransportEmploye()
    {
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};
        JSONObject feuilleDeTempsHebdomadaire = lireFichierJSON();

        int numeroEmploye = feuilleDeTempsHebdomadaire.getInt("numero_employe");
        
        for (int i = 0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));

            for (int j = 0; j < feuilleDeTempsJournalier.size(); ++j) 
            {
                JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                if ( (projetCourant.getInt("projet") == 777) && ( (numeroEmploye >= 1000) && (numeroEmploye <= 5000) ) )
                {
                    resultat.add("L'employe n'a pas le droit d'utiliser du temps de transport");
                }
            }
        }
    }
    
    @SuppressWarnings("empty-statement")
    public JSONObject lireFichierJSON ()
    {
        String jsonTxt = "";
     try
        {
            jsonTxt = FileReader.loadFileIntoString(args[0], "UTF-8");
        }catch(IOException ex)
        {
            System.err.println("Fichier introuvable !");
        };
        return JSONObject.fromObject(jsonTxt);
    }

    public void ecrireFichierJSON ( JSONArray jsonArray )
    {
        try 
        {
            FileWriter jsonFileWriter = null;
            jsonFileWriter = new FileWriter(args[1]);
            
            jsonFileWriter.write(jsonArray.toString(3));
            jsonFileWriter.flush();
            jsonFileWriter.close();
        } catch (IOException ex) 
        {
            System.err.println("Erreur ecriture fichier !");
            System.exit(2);
        }
    }
}
