package inf2015ProjetDeSession;

import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_ADMINISTRATION;
import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_DEVELOPPEMENT;
import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_EXPLOITATION;
import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_DIRECTION;

import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_ADMINISTRATION;
import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_DEVELOPPEMENT;
import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_EXPLOITATION;

import static inf2015ProjetDeSession.INF2015ProjetDeSession.TEMPS_MAXIMUM_TELE_TRAVAIL_EMPLOYE_ADMINISTRATION;

import java.util.Arrays;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

/**
 * @author Equipe19
 */
public class Employe {

    protected int numeroEmploye;
    protected double[] tempsTravail;
    protected JSONObject feuilleDeTempsHebdomadaire;

    public Employe(JSONObject feuilleDeTempsHebdomadaire) 
    {
        this.numeroEmploye = feuilleDeTempsHebdomadaire.getInt("numero_employe");
        this.tempsTravail = new double[2];
        this.feuilleDeTempsHebdomadaire = feuilleDeTempsHebdomadaire;
    }

    public boolean estEmployeAdministration() 
    {
        return (numeroEmploye < 1000);
    }

    public boolean estEmployeDeveloppement() 
    {
        return ((numeroEmploye >= 1000) && (numeroEmploye < 2000));
    }

    public boolean estEmployeExploitation() 
    {
        return (numeroEmploye >= 2000 && numeroEmploye <= 5000);
    }

    public boolean estEmployeDirection() 
    {
        return (numeroEmploye > 5000);
    }

    public boolean estPresident() 
    {
        return (numeroEmploye == 6000);
    }

    public void calculerTempsTravaille() 
    {
        calculerTempsAuBureauLaSemaine();
        calculerTempsTeleTravailLaSemaine();        
    }

    public void calculerTempsAuBureauLaSemaine() 
    {
        List<Integer> codesProjetConges = Arrays.asList(996, 997, 998, 999);
        double tempsAuBureauLaSemaine = 0;
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};
        for (int i = 0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));
            for (int j = 0; j < feuilleDeTempsJournalier.size(); ++j) 
            {
                JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                if ((projetCourant.getInt("projet") <= 900) || (codesProjetConges.contains(projetCourant.getInt("projet")))) 
                {
                    tempsAuBureauLaSemaine += projetCourant.getInt("minutes");
                }
            }
        }
        tempsTravail[0] = tempsAuBureauLaSemaine / 60.0;
        System.out.println("Bureau -> " + tempsTravail[0]);
    }

    public void calculerTempsTeleTravailLaSemaine() 
    {
        double tempsTeleTravailLaSemaine = 0;
        List<Integer> codesProjetConges = Arrays.asList(996, 997, 998, 999);
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};

        for (int i = 0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));
            for (int j = 0; j < feuilleDeTempsJournalier.size(); ++j) 
            {
                JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                if ((projetCourant.getInt("projet") > 900) && (!codesProjetConges.contains(projetCourant.getInt("projet")))
                        || (projetCourant.getInt("projet") == 777) && (estEmployeDirection() && !estPresident())) 
                {
                    tempsTeleTravailLaSemaine += projetCourant.getInt("minutes");
                }
            }
        }
            tempsTravail[1] = tempsTeleTravailLaSemaine / 60.0;
            System.out.println("Tele -> " + tempsTravail[1]);
    }

    public JSONArray verifierRegles(JSONArray apresContraintes) 
    {
        if (apresContraintes == null) 
        {
            apresContraintes = new JSONArray();
        }
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};
        
        verifierTempsTransportLaSemaine(apresContraintes);
        
        apresContraintes = verifierTempsMinimal(feuilleDeTempsHebdomadaire, jours, apresContraintes, numeroEmploye);

        if (estEmployeAdministration()) 
        {
            apresContraintes = verifierReglesEmployeAdministration(apresContraintes, tempsTravail[0], tempsTravail[1]);
        } else if (estEmployeDeveloppement()) 
        {
            apresContraintes = verifierReglesEmployeDeveloppement(apresContraintes, tempsTravail[0]);
        } else if (estEmployeExploitation()) 
        {
            apresContraintes = verifierReglesEmployeExploitation(apresContraintes, tempsTravail[0]);
        } else if (estEmployeDirection()) 
        {
            apresContraintes = verifierReglesEmployeDirection(apresContraintes, tempsTravail[0]);
        }
        return apresContraintes;
    }

    public JSONArray verifierTempsTransportLaSemaine(JSONArray apresContraintes)
    {
        double tempsTransportLaSemaine = 0;
        String[] jours = {"jour1", "jour2", "jour3", "jour4", "jour5", "weekend1", "weekend2"};

        for (int i = 0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));
            for (int j = 0; j < feuilleDeTempsJournalier.size(); ++j) 
            {
                JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                if ( projetCourant.getInt("projet") == 777 )
                {
                    tempsTransportLaSemaine += projetCourant.getInt("minutes");
                }
            }
        }
        tempsTransportLaSemaine = tempsTransportLaSemaine/60;
        if ( tempsTransportLaSemaine > 5 && !estPresident() )
        {
            apresContraintes.add("L'employe a depasse les 5h de temps de tranport permis");
        }        
        return apresContraintes;
    }
    
    public JSONArray verifierTempsMinimal(JSONObject feuilleDeTempsHebdomadaire, String[] jours, JSONArray jsonArray, int numeroEmploye) {
        double tempsAuBureauJourX = 0.0;
        List<Integer> codesProjetConges = Arrays.asList(996, 997, 998, 999);
        
        for (int i = 0; i < jours.length; ++i) 
        {
            JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jours[i]));
            for (int j = 0; j < feuilleDeTempsJournalier.size(); ++j) 
            {
                JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
                if ((projetCourant.getInt("projet") <= 900) || (codesProjetConges.contains(projetCourant.getInt("projet")))) 
                {
                    if (!jours[i].equals("weekend1") && !jours[i].equals("weekend2")) {
                        tempsAuBureauJourX += (projetCourant.getInt("minutes"));
                    }
                }
            }
            tempsAuBureauJourX = tempsAuBureauJourX / 60.0;
            System.out.println("ParJour -> " + tempsAuBureauJourX);

            jsonArray = verifierTempsMininalParJour(jsonArray, numeroEmploye, tempsAuBureauJourX, jours[i]);
            jsonArray = verifierTempsMaximalParJour(jsonArray, numeroEmploye, tempsAuBureauJourX, jours[i]);
            tempsAuBureauJourX = 0;
        }
        return jsonArray;
    }

    public JSONArray verifierTempsMininalParJour(JSONArray jsonArray, int numeroEmploye, double tempsAuBureauJourX, String jour) 
    {
        if (estEmployeAdministration() && (tempsAuBureauJourX < 4) && (!jour.equals("weekend1") && !jour.equals("weekend2"))) 
        {
            jsonArray.add("L'employé d'administration n'a pas travaillé les 4 heures minimales au bureau le " + jour + ".");
        } else if (estEmployeDeveloppement() && (tempsAuBureauJourX < 6) && (!jour.equals("weekend1") && !jour.equals("weekend2"))) 
        {
            jsonArray.add("L'employé de developpement n'a pas travaillé les 6 heures minimales au bureau le " + jour + ".");
        } else if (estEmployeExploitation() && (tempsAuBureauJourX < 6) && (!jour.equals("weekend1") && !jour.equals("weekend2"))) 
        {
            jsonArray.add("L'employé d'exploitation n'a pas travaillé les 6 heures minimales au bureau le " + jour + ".");
        } else if (estEmployeDirection() && (tempsAuBureauJourX < 8) && (!jour.equals("weekend1") && !jour.equals("weekend2"))) 
        {
            jsonArray.add("L'employé de direction n'a pas travaillé les 6 heures minimales au bureau le " + jour + ".");
        }
        return jsonArray;
    }

    public JSONArray verifierTempsMaximalParJour(JSONArray jsonArray, int numeroEmploye, double tempsAuBureauJourX, String jour) 
    {
        if (estEmployeAdministration() && ((tempsAuBureauJourX > 24 && !verifierPresenceConge(jour)) || tempsAuBureauJourX > 32)) 
        {
            jsonArray.add("L'employé d'administration a dépassé le nombre d'heures permis au bureau le " + jour + ".");
        } else if (estEmployeDeveloppement() && ((tempsAuBureauJourX > 24 && !verifierPresenceConge(jour)) || tempsAuBureauJourX > 32)) 
        {
            jsonArray.add("L'employé de developpement a dépassé le nombre d'heures permis au bureau le " + jour + ".");
        } else if (estEmployeExploitation() && ((tempsAuBureauJourX > 24 && !verifierPresenceConge(jour)) || tempsAuBureauJourX > 32)) 
        {
            jsonArray.add("L'employé d'exploitation a dépassé le nombre d'heures permis au bureau le " + jour + ".");
        } else if (estEmployeDirection() && ((tempsAuBureauJourX > 24 && !verifierPresenceConge(jour)) || tempsAuBureauJourX > 32)) 
        {
            jsonArray.add("L'employé de direction a dépassé le nombre d'heures permis au bureau le " + jour + ".");
        }
        return jsonArray;
    }

    public boolean verifierPresenceConge(String jour) 
    {
        boolean resultat = false;

        JSONArray feuilleDeTempsJournalier = (JSONArray) JSONSerializer.toJSON(feuilleDeTempsHebdomadaire.getString(jour));
        for (int j = 0; j < feuilleDeTempsJournalier.size(); ++j) 
        {
            JSONObject projetCourant = feuilleDeTempsJournalier.getJSONObject(j);
            if ((projetCourant.getInt("projet") == 997) || (projetCourant.getInt("projet") == 998)) 
            {
                if (!jour.equals("weekend1") && !jour.equals("weekend2")) 
                {
                    resultat = true;
                }
            }
        }
        return resultat;
    }

    public JSONArray verifierReglesEmployeAdministration(JSONArray resultat, double tempsAuBureauLaSemaine, double tempsTeleTravailLaSemaine) 
    {
        if (tempsAuBureauLaSemaine < TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_ADMINISTRATION) 
        {
            resultat.add("L'employé d'administration a passé moins de 37.5 heures au bureau.");
        }

        if (tempsAuBureauLaSemaine > TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_ADMINISTRATION) 
        {
            resultat.add("L'employé d'administration a depassé le nombre d'heure permis au bureau");
        }

        if (tempsTeleTravailLaSemaine > TEMPS_MAXIMUM_TELE_TRAVAIL_EMPLOYE_ADMINISTRATION) 
        {
            resultat.add("L'employé d'administration a dépassé le nombre d'heures de télétravail permis.");
        }
        return resultat;
    }

    public JSONArray verifierReglesEmployeDeveloppement(JSONArray resultat, double tempsAuBureauLaSemaine) 
    {
        if (tempsAuBureauLaSemaine < TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_DEVELOPPEMENT) 
        {
            resultat.add("L'employe de developpement n'a pas travaille le nombre d'heure minimal.");
        }

        if (tempsAuBureauLaSemaine > TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_DEVELOPPEMENT) 
        {
            resultat.add("L'employé de developpement a depassé le nombre d'heure permis au bureau");
        }
        return resultat;
    }

    public JSONArray verifierReglesEmployeExploitation(JSONArray resultat, double tempsAuBureauLaSemaine) 
    {
        if (tempsAuBureauLaSemaine < TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_EXPLOITATION) 
        {
            resultat.add("L'employe d'exploitation n'a pas travaille le nombre d'heure minimal.");
        }

        if (tempsAuBureauLaSemaine > TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_EXPLOITATION) 
        {
            resultat.add("L'employé d'exploitation a depassé le nombre d'heure permis au bureau");
        }
        return resultat;
    }

    public JSONArray verifierReglesEmployeDirection(JSONArray resultat, double tempsAuBureauLaSemaine) 
    {
        if (tempsAuBureauLaSemaine < TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_DIRECTION) 
        {
            resultat.add("L'employé de direction a passé moins de 43 heures au bureau.");
        }
        return resultat;
    }
}
