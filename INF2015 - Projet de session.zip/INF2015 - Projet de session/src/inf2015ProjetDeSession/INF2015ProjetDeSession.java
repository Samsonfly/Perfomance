package inf2015ProjetDeSession;

import net.sf.json.JSONArray;

/**
 * @author Equipe 19
 */
public class INF2015ProjetDeSession 
{
    /**
     * @throws java.lang.Exception
     */
    public static final double TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_ADMINISTRATION = 37.5;
    public static final double TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_DEVELOPPEMENT = 38;
    public static final double TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_EXPLOITATION = 39.5;
    public static final double TEMPS_MINIMUM_AU_BUREAU_EMPLOYE_DIRECTION = 43;
    
    public static final double TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_ADMINISTRATION = 41.5;
    public static final double TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_DEVELOPPEMENT = 43;
    public static final double TEMPS_MAXIMUM_AU_BUREAU_EMPLOYE_EXPLOITATION = 43;
    

    public static final int TEMPS_MAXIMUM_TELE_TRAVAIL_EMPLOYE_ADMINISTRATION = 10;
    
    public static final int TEMPS_MINIMUM_AU_BUREAU_JOURS_OUVRABLES_EMPLOYE_ADMINISTRATION = 4;
    public static final int TEMPS_MINIMUM_AU_BUREAU_JOURS_OUVRABLES_EMPLOYE_DEVELOPPEMENT = 6;
    public static final int TEMPS_MINIMUM_AU_BUREAU_JOURS_OUVRABLES_EMPLOYE_EXPLOITATION = 6;
    public static final int TEMPS_MINIMUM_AU_BUREAU_JOURS_OUVRABLES_EMPLOYE_DIRECTION = 8;
    
    public static void main(String[] args) throws Exception
    {
        Employe employe;
        StructureJson json = new StructureJson(args);

        employe = new Employe( json.lireFichierJSON() );
        json.verifierContraintes();
        
        employe.calculerTempsTravaille();
        JSONArray regles = employe.verifierRegles(json.resultat);
        
        json.ecrireFichierJSON(regles);
    }
}